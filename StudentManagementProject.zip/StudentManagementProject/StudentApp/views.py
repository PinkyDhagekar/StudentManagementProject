from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.views.decorators.cache import never_cache

from StudentApp.models import Course, Student, City


# Create your views here.
def login_fun(request):
    if request.method == 'POST':  # it will execute when clicked on login button in login page
        user_name = request.POST['txtUserName']
        user_pswd = request.POST['txtPass']
        u1 = authenticate(username=user_name, password=user_pswd)  # predefined function which will
        # check wheather the entered username and password #are present or not in usertable
        if u1 is not None:
            if u1.is_superuser:
                request.session['Uname'] = user_name
                login(request, u1)
                return redirect('home')
        else:
            return render(request, 'login.html',
                          {'msg': 'Username or Password is incorrect'})
    else:
        return render(request, 'login.html')


def register_fun(request):
    if request.method == 'POST':  # it will execute when clicked on register button in register page
        user_name = request.POST['txtUserName']
        user_pswd = request.POST['txtPass']
        user_email = request.POST['txtEmail']
        if User.objects.filter(username=user_name).exists():
            return render(request, 'register.html', {'msg': 'Use proper Username and Password'})
        else:
            u1 = User.objects.create_superuser(username=user_name, password=user_pswd, email=user_email)
        u1.save()
        return redirect('log')
    else:  # it will execute when clicked on hyperlink in login page
        return render(request, 'register.html')


@login_required
@never_cache
def home_fun(request):
    return render(request, 'home.html', {'data': request.session['Uname']})


@login_required
@never_cache
def add_course(request):
    if request.method == 'POST':
        c1 = Course()
        c1.course_name = request.POST['txtCname']
        c1.course_duration = request.POST['txtCDuration']
        c1.course_fees = int(request.POST['txtCFees'])
        c1.save()
        return render(request, 'addcourse.html', {'msg': 'Successfully added'})
    else:
        return render(request, 'addcourse.html')


@login_required
@never_cache
def display_course(request):
    course_data = Course.objects.all()  # it will return lists of objects

    return render(request, 'displaycourse.html', {'data': course_data})


@login_required
@never_cache
def update_course(request, courseid):
    c1 = Course.objects.get(id=courseid)
    if request.method == 'POST':
        c1.course_name = request.POST['txtCname']
        c1.course_duration = request.POST['txtCDuration']
        c1.course_fees = int(request.POST['txtCFees'])
        c1.save()
        return redirect('display_course')
    else:
        return render(request, 'updatecourse.html', {'data': c1})


@login_required
@never_cache
def delete_course(request, courseid):
    c1 = Course.objects.get(id=courseid)
    c1.delete()
    return redirect('display_course')


@login_required
@never_cache
def add_student(request):
    if request.method == 'POST':
        s1 = Student()
        s1.stud_name = request.POST['txtSName']
        s1.stud_phno = int(request.POST['txtSPhone'])
        s1.stud_email = request.POST['txtSMail']
        s1.stud_city = City.objects.get(city_name=request.POST['ddlCity'])  # this is only use for foreignkey contraints
        s1.stud_course = Course.objects.get(course_name=request.POST['ddlCourse'])
        s1.paid_fees = int(request.POST['txtSPFees'])
        c1 = Course.objects.get(course_name=request.POST['ddlCourse'])
        s1.pending_fees = c1.course_fees - s1.paid_fees
        s1.save()
        return redirect('add_student')
    else:
        city = City.objects.all()
        course = Course.objects.all()
        return render(request, 'addstudent.html', {'CityData': city, 'CourseData': course})


@login_required
@never_cache
def display_student(request):
    s1 = Student.objects.all()
    return render(request, 'displaystudent.html', {'StudentData': s1})


@login_required
@never_cache
def update_stud(request, studid):
    s1 = Student.objects.get(id=studid)
    if request.method == 'POST':
        s1.stud_name = request.POST['txtSName']
        s1.stud_phno = int(request.POST['txtSPhone'])
        s1.stud_email = request.POST['txtSMail']
        s1.stud_city = City.objects.get(city_name=request.POST['ddlCity'])  # this is only use for foreignkey contraints
        s1.stud_course = Course.objects.get(course_name=request.POST['ddlCourse'])
        s1.paid_fees = s1.paid_fees + int(request.POST['txtSPFees'])
        c1 = Course.objects.get(course_name=request.POST['ddlCourse'])
        if s1.pending_fees > 0:
            s1.pending_fees = c1.course_fees - s1.paid_fees
        else:
            s1.pending_fees = 0
        s1.save()
        return redirect('display_student')
    else:
        city = City.objects.all()
        course = Course.objects.all()
        return render(request, 'updatestudent.html',
                      {'student': s1, 'CityData': city, 'CourseData': course})


@login_required
@never_cache
def delete_stud(request, studid):
    s1 = Student.objects.get(id=studid)
    s1.delete()
    return redirect('display_student')


def logout_fun(request):
    logout(request)
    return redirect('log')
