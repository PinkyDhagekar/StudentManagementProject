from django.urls import path

from StudentApp import views

urlpatterns = [
    path('', views.login_fun, name='log'),  # it will redirect to login.html page.
    path('reg', views.register_fun, name='reg'),  # it will redirect to register.html page.
    path('home', views.home_fun, name='home'),  # it will redirect to home.html page.
    path('add_course', views.add_course, name='add_course'),  # it will redirect to addcourse.html page
    # and inserting course into course table.
    path('display_course', views.display_course, name='display_course'),  # it will collect data from course table
    # and send to displaycourse.html page.
    path('update_course/<int:courseid>', views.update_course, name='update_course'),  # it will update the course data.
    path('delete_course/<int:courseid>', views.delete_course, name='delete_course'),  # it will delete the course data.
    path('add_student', views.add_student, name='add_student'),  # it will redirect to addstudent.html page.
    path('display_student', views.display_student, name='display_student'),  # it will collect data from student table
    # and send to displaystudent.html page
    path('update_stud/<int:studid>', views.update_stud, name='update_stud'),  # it will update the student data.
    path('delete_stud/<int:studid>', views.delete_stud, name='delete_stud'),  # it will delete the student data.
    path('logout', views.logout_fun, name='logout')
]
